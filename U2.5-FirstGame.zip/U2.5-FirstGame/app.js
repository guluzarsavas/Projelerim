new Vue({
    el: "#app",
    data:{
       playerHeal: 100,
       monsterHeal: 100,
       gameIsOn: false,
       logs: [  ]
    },
    methods:{
       startGame: function(){
          this.gameIsOn= true
       },
       attack: function(){
           var point= Math.ceil(Math.random()*10)
           this.monsterHeal-=point;
           this.addToLog({turn: "p", text: "Player's Attack (" +point + ")"})
           this.monsterAttack();
           
         },
       specialAttack: function(){
           var point= Math.ceil(Math.random()*25)
           this.monsterHeal-=point;
           this.addToLog({turn: "p", text: " Special Player Attack (" +point + ")"})
           this.monsterAttack();
           
        },
       help: function(){
           var point=Math.ceil(Math.random()*20)
           this.playerHeal+=point;/*saldırmak yerine kendine puan ekler ama sonra canavar da saldırır tekrar */
           this.addToLog({turn: "p", text: " Support (" +point + ")"})
           this.monsterAttack();
           
       },
       giveUp: function(){
           this.playerHeal=0;
           this.addToLog({turn: "p", text: " Give Up (" +point + ")"})
           
       },
       monsterAttack: function(){
           var point= Math.ceil(Math.random()*15)
           this.playerHeal-=point;
           this.addToLog({turn: "m", text: " Monster's Attack (" +point + ")"})
        
       },
       addToLog: function(log){
           this.logs.push(log);
       }

    },
    watch : {
        playerHeal: function(value){
            if(value<=0){
                this.playerHeal=0;
               if( confirm("Game Over || Try Again?")){
                   this.playerHeal=100;
                   this.monsterHeal=100;
                   this.logs= [];
               }
            }
            else if(value>=100){
                 this.playerHeal=100;
            }
            else
                this.playerHeal=value;
                  
        },
        monsterHeal: function(value){
            if(value<=0){
                this.monsterHeal=0;
                if(confirm("Congratulations!")){
                    this.playerHeal=100;/*yeni oyunda canları 100 yap tekrar.*/
                    this.monsterHeal=100;
                    this.logs= [];/* oyun bitiminde logları temizlemek için*/
                }
            }
            else if(value>=100){
                this.monsterHeal=100;
            }
            else
              this.monsterHeal=value;

        }

        

    }
})